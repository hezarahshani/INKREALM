<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'config.php';

if(isset($_POST['register'])){

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users(username,email,password)
            VALUES('$username','$email','$password')";
        include 'send_verification.php';

$new_user_id = mysqli_insert_id($conn);

sendVerification($email, $token);
    mysqli_query($conn, $sql);

    header("Location: login.php");
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Register</title>

<style>

body{
    background:#070b14;
    color:white;
    font-family:Arial;
    text-align:center;
}

form{
    width:300px;
    margin:auto;
    margin-top:100px;
}

input{
    width:100%;
    padding:12px;
    margin:10px 0;
}

button{
    width:100%;
    padding:12px;
    background:#f97316;
    border:none;
    color:white;
}

</style>

</head>

<body>

<form method="POST">

<h1>Register</h1>

<input type="text" name="username" placeholder="Username" required>

<input type="email" name="email" placeholder="Email" required>

<input type="password" name="password" placeholder="Password" required>

<button type="submit" name="register">
Register
</button>

</form>

</body>

</html>