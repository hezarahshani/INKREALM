<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "inkrealm_db"
);

if(!$conn){
    die("Database Connection Failed");
}

?>
