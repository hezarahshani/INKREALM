<?php

session_start();

include 'config.php';

/* CHECK ADMIN */

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$admin = mysqli_query(
    $conn,
    "SELECT * FROM users
    WHERE id='$user_id'"
);

$admin_data = mysqli_fetch_assoc($admin);

if($admin_data['role'] != 'admin'){
    die("Access Denied");
}

/* DELETE STORY */

if(isset($_GET['delete_story'])){

    $delete_id = $_GET['delete_story'];

    mysqli_query(
        $conn,
        "DELETE FROM stories
        WHERE id='$delete_id'"
    );

    header("Location: admin.php");
    exit();
}

/* DELETE COMMENT */

if(isset($_GET['delete_comment'])){

    $delete_comment = $_GET['delete_comment'];

    mysqli_query(
        $conn,
        "DELETE FROM comments
        WHERE id='$delete_comment'"
    );

    header("Location: admin.php");
    exit();
}
/* APPROVE CONTRACT */

if(isset($_GET['approve_contract'])){

    $contract_id = $_GET['approve_contract'];

    mysqli_query(

        $conn,

        "UPDATE contracts
        SET status='Approved'
        /* GET AUTHOR */

$get_author = mysqli_query(

    $conn,

    "SELECT author_id
    FROM contracts
    WHERE id='$contract_id'"

);

$author_data = mysqli_fetch_assoc($get_author);

$author_id = $author_data['author_id'];

/* SEND NOTIFICATION */

mysqli_query(

    $conn,

    "INSERT INTO notifications
    (user_id, message)

    VALUES

    ('$author_id',
    'Senior Editor Heza Ma approved your contract.')"

);
        WHERE id='$contract_id'"

    );

    header("Location: admin.php");
    exit();
}

/* REJECT CONTRACT */

if(isset($_GET['reject_contract'])){

    $contract_id = $_GET['reject_contract'];

    mysqli_query(

        $conn,

        "UPDATE contracts
        SET status='Rejected'
        WHERE id='$contract_id'"

    );

    header("Location: admin.php");
    exit();
}
/* COUNTS */

$total_users = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM users")
);

$total_stories = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM stories")
);

$total_comments = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM comments")
);

/* GET STORIES */

$stories = mysqli_query(
    $conn,
    "SELECT * FROM stories
    ORDER BY id DESC"
);
/* GET CONTRACTS */

$contracts = mysqli_query(

    $conn,

    "SELECT contracts.*,
    stories.title,
    users.username

    FROM contracts

    JOIN stories
    ON contracts.story_id = stories.id

    JOIN users
    ON contracts.author_id = users.id

    ORDER BY contracts.id DESC"

);
/* GET WITHDRAWALS */

$withdrawals = mysqli_query(

    $conn,

    "SELECT withdrawals.*,
    users.username

    FROM withdrawals

    JOIN users
    ON withdrawals.user_id = users.id

    ORDER BY withdrawals.id DESC"

);
/* GET COMMENTS */

$comments = mysqli_query(
    $conn,
    "SELECT * FROM comments
    ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html>

<head>

<title>Heza Ma - Senior Editor</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#050816;
    color:white;
    font-family:'Poppins',sans-serif;
}

/* HEADER */

.header{

    background:#0f172a;

    padding:25px 60px;

    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{

    font-size:32px;
    font-weight:700;
}

.logo span{
    color:#ff7b29;
}

.admin-name{
    color:#ffb37a;
}

/* CONTAINER */

.container{
    width:90%;
    margin:auto;
    padding:50px 0;
}

/* STATS */

.stats{

    display:grid;

    grid-template-columns:
    repeat(auto-fit,minmax(250px,1fr));

    gap:25px;

    margin-bottom:50px;
}

.card{

    background:#111827;

    padding:35px;

    border-radius:20px;
}

.card h2{
    color:#ff7b29;
    margin-bottom:15px;
}

/* SECTION */

.section{
    margin-top:50px;
}

.section h1{
    margin-bottom:25px;
}

/* ITEM */

.item{

    background:#111827;

    padding:25px;

    border-radius:20px;

    margin-bottom:20px;
}

.delete-btn{

    display:inline-block;

    margin-top:15px;

    padding:10px 18px;

    background:#dc2626;

    color:white;

    text-decoration:none;

    border-radius:10px;
}

.comment-user{
    color:#ffb37a;
    margin-bottom:10px;
}

</style>

</head>

<body>

<!-- HEADER -->

<div class="header">

<div class="logo">
INK<span>REALM</span>
</div>

<div class="admin-name">
Senior Editor: Heza Ma
</div>

</div>

<!-- CONTAINER -->

<div class="container">

<!-- STATS -->

<div class="stats">

<div class="card">

<h2>Total Users</h2>

<p style="font-size:35px;">

<?php echo $total_users; ?>

</p>

</div>

<div class="card">

<h2>Total Stories</h2>

<p style="font-size:35px;">

<?php echo $total_stories; ?>

</p>

</div>

<div class="card">

<h2>Total Comments</h2>

<p style="font-size:35px;">

<?php echo $total_comments; ?>

</p>

</div>

</div>

<!-- STORIES -->

<div class="section">

<h1>📚 Manage Stories</h1>

<?php while($story = mysqli_fetch_assoc($stories)){ ?>

<div class="item">

<h2>

<?php echo $story['title']; ?>

</h2>

<p>

<?php echo $story['description']; ?>

</p>

<a

class="delete-btn"

href="admin.php?delete_story=<?php echo $story['id']; ?>">

Delete Story

</a>

</div>

<?php } ?>

</div>

<!-- COMMENTS -->

<div class="section">

<h1>💬 Manage Comments</h1>

<?php while($comment = mysqli_fetch_assoc($comments)){ ?>

<div class="item">

<h3 class="comment-user">

<?php echo $comment['username']; ?>

</h3>

<p>

<?php echo $comment['comment']; ?>

</p>

<a

class="delete-btn"

href="admin.php?delete_comment=<?php echo $comment['id']; ?>">

Delete Comment

</a>

</div>

<?php } ?>

</div>

</div>

<div class="section">

<h1>📜 Contract Applications</h1>

<?php while($contract = mysqli_fetch_assoc($contracts)){ ?>

<div class="item">

<h2>

<?php echo $contract['title']; ?>

</h2>

<p>

Author:
<?php echo $contract['username']; ?>

</p>

<p>

Status:
<?php echo $contract['status']; ?>

</p>

<br>

<a

class="delete-btn"

style="background:#16a34a;"

href="admin.php?approve_contract=<?php echo $contract['id']; ?>">

Approve

</a>

<a

class="delete-btn"

style="background:#dc2626;"

href="admin.php?reject_contract=<?php echo $contract['id']; ?>">

Reject

</a>

</div>

<?php } ?>

</div>
/* GET WITHDRAWALS */

$withdrawals = mysqli_query(

    $conn,

    "SELECT withdrawals.*,
    users.username

    FROM withdrawals

    JOIN users
    ON withdrawals.user_id = users.id

    ORDER BY withdrawals.id DESC"

);
</body>

</html>