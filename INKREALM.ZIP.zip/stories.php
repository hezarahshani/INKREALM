<?php

include 'config.php';
session_start();

$user_coins = 0;

if(isset($_SESSION['user_id'])){

    $uid = $_SESSION['user_id'];

    $user_query = mysqli_query(

        $conn,

        "SELECT coins
        FROM users
        WHERE id='$uid'"

    );

    $user_data = mysqli_fetch_assoc($user_query);
    /* GET EARNINGS */

$earnings_query = mysqli_query(

    $conn,

    "SELECT amount
    FROM earnings
    WHERE user_id='$uid'"

);

$earnings_data = mysqli_fetch_assoc($earnings_query);

$user_earnings = 0;

if($earnings_data){
    $user_earnings = $earnings_data['amount'];
}

    $user_coins = $user_data['coins'];
}

/* SEARCH + TRENDING SYSTEM */

if(isset($_GET['search'])){

    $search = mysqli_real_escape_string(
        $conn,
        $_GET['search']
    );

    $query = "SELECT * FROM stories

    WHERE title LIKE '%$search%'

    OR genre LIKE '%$search%'

    ORDER BY likes DESC, views DESC";

}else{

    $query = "SELECT * FROM stories

    ORDER BY likes DESC, views DESC";
}

$stories = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>INKREALM</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#050816;
    color:white;
    font-family:'Poppins',sans-serif;
}

/* NAVBAR */

.navbar{

    width:100%;
    padding:20px 80px;

    display:flex;
    justify-content:space-between;
    align-items:center;

    background:#0f172a;
}

.logo{

    font-size:34px;
    font-weight:700;
}

.logo span{
    color:#ff7b29;
}

.nav-links a{

    color:white;

    text-decoration:none;

    margin-left:25px;
}
<a href="watch_ads.php">

Watch Ads

</a>
/* HERO */
/* SLIDER */

.slider{

    position:relative;

    width:100%;

    height:85vh;

    overflow:hidden;
}

.slides{
    display:none;
    position:absolute;
    width:100%;
    height:100%;
}

.slides img{

    width:100%;
    height:100%;

    object-fit:cover;

    filter:brightness(40%);
}

.slide-content{

    position:absolute;

    top:50%;
    left:50%;

    transform:translate(-50%,-50%);

    text-align:center;

    width:80%;
}

.slide-content h1{

    font-size:75px;

    margin-bottom:20px;
}

.slide-content p{

    font-size:22px;

    color:#e5e7eb;

    margin-bottom:35px;
}

.slide-content a{

    display:inline-block;

    padding:15px 30px;

    background:#ff7b29;

    color:white;

    text-decoration:none;

    border-radius:10px;

    font-size:18px;
}

/* FADE */

.fade{
    animation:fade 1s;
}

@keyframes fade{

    from{
        opacity:0.4;
    }

    to{
        opacity:1;
    }
}


/* SEARCH */

.search-box{

    text-align:center;

    margin-top:50px;
}

.search-box input{

    width:350px;

    padding:15px;

    border:none;

    border-radius:10px;

    background:#111827;

    color:white;

    font-size:16px;
}

.search-box button{

    padding:15px 20px;

    background:#ff7b29;

    border:none;

    border-radius:10px;

    color:white;

    cursor:pointer;
}

/* TITLE */

.section-title{

    text-align:center;

    margin-top:50px;
    margin-bottom:50px;

    font-size:42px;
}

/* STORIES */

.story-container{

    width:90%;

    margin:auto;

    display:grid;

    grid-template-columns:
    repeat(auto-fit,minmax(300px,1fr));

    gap:35px;

    padding-bottom:80px;
}

.story-card{

    position:relative;

    background:#111827;

    border-radius:20px;

    overflow:hidden;

    transition:0.4s;
}

.story-card:hover{

    transform:translateY(-10px);
}

.trending{

    position:absolute;

    top:0;
    left:0;

    background:#ff7b29;

    padding:10px 18px;

    border-radius:0 0 15px 0;

    font-size:14px;

    font-weight:bold;

    z-index:10;
}

.cover{

    width:100%;

    height:260px;

    object-fit:cover;
}

.story-content{
    padding:25px;
}

.story-content h2{

    margin-bottom:15px;

    font-size:24px;
}

.story-content p{

    color:#9ca3af;

    line-height:1.8;
}

.stats{

    margin-top:15px;

    color:#cbd5e1;
}

.genre{

    display:inline-block;

    margin-top:18px;

    padding:8px 16px;

    border-radius:30px;

    background:#1f2937;

    color:#ffb37a;

    font-size:14px;
}

.read-btn{

    display:inline-block;

    margin-top:25px;

    padding:13px 24px;

    background:#ff7b29;

    color:white;

    text-decoration:none;

    border-radius:10px;
}

/* FOOTER */

.footer{

    background:#0f172a;

    text-align:center;

    padding:40px;

    color:#94a3b8;
}

</style>

</head>

<body>

<!-- NAVBAR -->

<div class="navbar">

<div class="logo">
INK<span>REALM</span>
</div>

<div class="nav-links">
 <a href="buy_coins.php">Buy Coins</a>   
 <span
style="
margin-right:20px;
color:#ffb37a;
font-weight:bold;
">

💰 <?php echo $user_coins; ?> Coins
<span
style="
margin-right:20px;
color:#4ade80;
font-weight:bold;
">

💵 $<?php echo number_format($user_earnings,2); ?>
<a href="withdraw.php">Withdraw</a>
</span>   

<a href="stories.php">Stories</a>

<a href="upload.php">Write</a>

<a href="chapter_upload.php">Chapters</a>

<a href="library.php">Library</a>

<a href="notifications.php">Notifications</a>



</div>

</div>

<!-- HERO SLIDER -->

<div class="slider">

<div class="slides fade">

<img
src="https://images.unsplash.com/photo-1512820790803-83ca734da794?q=80&w=1920&auto=format&fit=crop">

<div class="slide-content">

<h1>
Enter the World of INKREALM
</h1>

<p>
Discover addictive stories from rising authors.
</p>

<a href="upload.php">
Start Writing
</a>

</div>

</div>

<div class="slides fade">

<img
src="https://images.unsplash.com/photo-1507842217343-583bb7270b66?q=80&w=1920&auto=format&fit=crop">

<div class="slide-content">

<h1>
Become The Next Bestseller
</h1>

<p>
Publish your imagination to the world.
</p>

<a href="stories.php">
Explore Stories
</a>

</div>

</div>

<div class="slides fade">

<img
src="https://images.unsplash.com/photo-1495446815901-a7297e633e8d?q=80&w=1920&auto=format&fit=crop">

<div class="slide-content">

<h1>
Read Without Limits
</h1>

<p>
Fantasy, Romance, Werewolf, Billionaire & More.
</p>

<a href="stories.php">
Read Now
</a>

</div>

</div>

</div>

<!-- SEARCH -->

<div class="search-box">

<form method="GET">

<input

type="text"

name="search"

placeholder="Search stories...">

<button type="submit">

Search

</button>

</form>

</div>

<!-- SECTION TITLE -->

<h1 class="section-title">
🔥 Trending Stories
</h1>

<!-- STORIES -->

<div class="story-container">

<?php while($story = mysqli_fetch_assoc($stories)){ ?>

<div class="story-card">

<?php if($story['likes'] >= 5){ ?>

<div class="trending">

🔥 Trending

</div>

<?php } ?>

<?php if(!empty($story['cover'])){ ?>

<img
class="cover"
src="uploads/<?php echo $story['cover']; ?>">

<?php } ?>

<div class="story-content">

<h2>

<?php echo $story['title']; ?>

</h2>

<p>

<?php echo substr($story['description'],0,120); ?>...

</p>

<div class="stats">

👁️ <?php echo $story['views']; ?>

&nbsp;&nbsp;

❤️ <?php echo $story['likes']; ?>

</div>

<div class="genre">

<?php echo $story['genre']; ?>

</div>

<br>

<a

class="read-btn"

href="read_story.php?id=<?php echo $story['id']; ?>">

Read Story

</a>

</div>

</div>

<?php } ?>

</div>

<!-- FOOTER -->

<div class="footer">

© 2026 INKREALM — Premium Storytelling Platform

</div>
<script>

let slideIndex = 0;

showSlides();

function showSlides(){

    let slides =
    document.getElementsByClassName("slides");

    for(let i = 0; i < slides.length; i++){

        slides[i].style.display = "none";
    }

    slideIndex++;

    if(slideIndex > slides.length){

        slideIndex = 1;
    }

    slides[slideIndex - 1].style.display = "block";

    setTimeout(showSlides, 4000);
}

</script>
</body>

</html>