<?php

session_start();

include 'config.php';

if(isset($_POST['login'])){

    $email = $_POST['email'];

    $password = $_POST['password'];

    $query = mysqli_query(

        $conn,

        "SELECT * FROM users
        WHERE email='$email'"
    );

    if(mysqli_num_rows($query) > 0){

        $user = mysqli_fetch_assoc($query);

        /* VERIFY EMAIL */

        if($user['verified'] == 0){

            die("Please verify your email first.");
        }

        /* VERIFY PASSWORD */

        if(password_verify($password, $user['password'])){

            $_SESSION['user_id'] = $user['id'];

            $_SESSION['username'] = $user['username'];

            header("Location: stories.php");
            exit();

        }else{

            echo "Invalid Email or Password";
        }

    }else{

        echo "Invalid Email or Password";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Login</title>

<style>

body{
    background:#050816;
    color:white;
    font-family:Arial;
    text-align:center;
}

form{

    width:320px;

    margin:auto;

    margin-top:100px;

    background:#111827;

    padding:30px;

    border-radius:20px;
}

input{

    width:100%;

    padding:12px;

    margin-bottom:15px;

    border:none;

    border-radius:10px;
}

button{

    width:100%;

    padding:12px;

    border:none;

    border-radius:10px;

    background:#ff7b29;

    color:white;

    font-weight:bold;

    cursor:pointer;
}

a{
    color:#ffb37a;
}

</style>

</head>

<body>

<form method="POST">

<h1>
Login Page
</h1>

<input
type="email"
name="email"
placeholder="Email"
required>

<input
type="password"
name="password"
placeholder="Password"
required>

<button
type="submit"
name="login">

Login

</button>

<p>

No account?

<a href="register.php">

Register

</a>

</p>

</form>

</body>

</html>