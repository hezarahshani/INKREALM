<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

include 'config.php';

function sendVerification($email, $user_id){

    $mail = new PHPMailer(true);

    try{

        /* SMTP SETTINGS */

        $mail->isSMTP();

        $mail->Host = 'smtp.gmail.com';

        $mail->SMTPAuth = true;

        /* YOUR GMAIL */

        $mail->Username = 'reignfourest@gmail.com';

        /* GOOGLE APP PASSWORD */

        $mail->Password = Nasrullah1738S;

        $mail->SMTPSecure =
        PHPMailer::ENCRYPTION_STARTTLS;

        $mail->Port = 587;

        /* EMAIL INFO */

        $mail->setFrom(

            'YOUR_GMAIL@gmail.com',

            'INKREALM'

        );

        $mail->addAddress($email);

        /* VERIFICATION LINK */

        $verify_link =
        "http://localhost/INKREALM/verify.php?id="
        .$user_id;

        /* EMAIL CONTENT */

        $mail->isHTML(true);

        $mail->Subject =
        'Verify Your INKREALM Account';

        $mail->Body = "

        <div style='
        font-family:Arial;
        padding:30px;
        background:#050816;
        color:white;
        '>

        <h1>
        Welcome to INKREALM
        </h1>

        <p>
        Click the button below
        to verify your account.
        </p>

        <a href='$verify_link'

        style='

        display:inline-block;

        padding:15px 25px;

        background:#ff7b29;

        color:white;

        text-decoration:none;

        border-radius:10px;

        margin-top:20px;

        '>

        Verify Account

        </a>

        </div>

        ";

        $mail->send();

    }catch(Exception $e){

        echo "

        Mail Error:
        ".$mail->ErrorInfo;

    }
}
?>