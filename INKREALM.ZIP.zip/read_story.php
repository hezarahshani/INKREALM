<?php

session_start();

include 'config.php';
/* CONTRACT APPLICATION */

if(isset($_GET['apply_contract'])){

    if(isset($_SESSION['user_id'])){

        $author_id = $_SESSION['user_id'];

        $apply_story = $_GET['apply_contract'];

        $check_contract = mysqli_query(

            $conn,

            "SELECT * FROM contracts
            WHERE story_id='$apply_story'"

        );

        if(mysqli_num_rows($check_contract) == 0){

            mysqli_query(

                $conn,

                "INSERT INTO contracts
                (story_id, author_id)

                VALUES

                ('$apply_story','$author_id')"

            );
        }

        header("Location: read_story.php?id=".$apply_story);
        exit();
    }
}
/* LIBRARY SYSTEM */

if(isset($_GET['save'])){

    if(isset($_SESSION['user_id'])){

        $user_id = $_SESSION['user_id'];

        $save_story = $_GET['save'];

        $check = mysqli_query(

            $conn,

            "SELECT * FROM library

            WHERE user_id='$user_id'

            AND story_id='$save_story'"

        );

        if(mysqli_num_rows($check) == 0){

            mysqli_query(

                $conn,

                "INSERT INTO library
                (user_id, story_id)

                VALUES

                ('$user_id','$save_story')"

            );
        }

        header("Location: read_story.php?id=".$save_story);
        exit();
    }
}

/* GET STORY ID */

$story_id = $_GET['id'];

/* ADD VIEW */

mysqli_query(
    $conn,
    "UPDATE stories
    SET views = views + 1
    WHERE id='$story_id'"
);

/* LIKE SYSTEM */

if(isset($_GET['like'])){

    $like_id = $_GET['like'];

    mysqli_query(
        $conn,
        "UPDATE stories
        SET likes = likes + 1
        WHERE id='$like_id'"
    );

    header("Location: read_story.php?id=".$like_id);
    exit();
}

/* COMMENT SYSTEM */

if(isset($_POST['submit_comment'])){

    $username = "Guest";

    if(isset($_SESSION['username'])){
        $username = $_SESSION['username'];
    }

    $comment = mysqli_real_escape_string(
        $conn,
        $_POST['comment']
    );

    mysqli_query(

        $conn,

        "INSERT INTO comments
        (story_id, username, comment)

        VALUES

        ('$story_id','$username','$comment')"

    );
}

/* GET STORY + AUTHOR */

$story = mysqli_query(

    $conn,

    "SELECT stories.*, users.username

    FROM stories

    JOIN users

    ON stories.user_id = users.id

    WHERE stories.id='$story_id'"

);

$story_data = mysqli_fetch_assoc($story);

/* GET CHAPTERS */
/* WORD COUNT */

$word_count = 0;

$word_query = mysqli_query(

    $conn,

    "SELECT chapter_content
    FROM chapters
    WHERE story_id='$story_id'"

);

while($wc = mysqli_fetch_assoc($word_query)){

    $word_count += str_word_count(
        strip_tags($wc['chapter_content'])
    );
}
$chapters = mysqli_query(

    $conn,

    "SELECT * FROM chapters
    WHERE story_id='$story_id'"

);

/* GET COMMENTS */

$comments = mysqli_query(

    $conn,

    "SELECT * FROM comments
    WHERE story_id='$story_id'

    ORDER BY id DESC"

);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>

<?php echo $story_data['title']; ?>
<a
href="gift.php?story_id=<?php echo $story['id']; ?>"
style="
display:inline-block;
margin-top:20px;
padding:12px 20px;
background:#ff7b29;
color:white;
text-decoration:none;
border-radius:10px;
">

🎁 Send Gift

</a>

</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#050816;
    color:white;
    font-family:'Poppins',sans-serif;
}

/* NAVBAR */

.navbar{

    width:100%;
    padding:20px 80px;

    display:flex;
    justify-content:space-between;
    align-items:center;

    background:#0f172a;
}

.logo{

    font-size:32px;
    font-weight:700;
}

.logo span{
    color:#ff7b29;
}

.nav-links a{

    color:white;

    text-decoration:none;

    margin-left:25px;
}

/* CONTAINER */

.container{

    width:900px;

    margin:auto;

    padding:40px 0;
}

/* COVER */

.cover{

    width:100%;

    height:500px;

    object-fit:cover;

    border-radius:20px;

    margin-bottom:30px;
}

/* STORY INFO */

h1{

    font-size:48px;

    margin-bottom:20px;
}

.description{

    color:#cbd5e1;

    line-height:1.8;

    margin-bottom:25px;
}

.author{

    margin-bottom:20px;

    color:#ffb37a;

    font-size:18px;
}

.author a{

    color:#ffb37a;

    text-decoration:none;
}

.stats{

    margin-bottom:30px;

    color:#9ca3af;
}

.like-btn{

    display:inline-block;

    padding:12px 20px;

    background:#ff4d6d;

    color:white;

    text-decoration:none;

    border-radius:10px;

    margin-bottom:40px;
}
<?php if($word_count >= 5000){ ?>

<div
style="
background:#111827;
padding:25px;
border-radius:20px;
margin-bottom:40px;
">

<h2 style="margin-bottom:15px;color:#ffb37a;">
📜 Contract Eligible
</h2>

<p style="margin-bottom:20px;">
This story has reached 5,000 words and
can now apply for an exclusive contract.
</p>

<a

href="read_story.php?id=<?php echo $story_id; ?>&apply_contract=<?php echo $story_id; ?>"

style="
display:inline-block;
padding:14px 22px;
background:#ff7b29;
color:white;
text-decoration:none;
border-radius:10px;
">

Apply For Contract

</a>

</div>

<?php } ?>
/* CHAPTERS */

.chapter{

    background:#111827;

    padding:35px;

    border-radius:20px;

    margin-bottom:35px;
}

.chapter h2{

    margin-bottom:20px;

    color:#ffb37a;
}

.chapter-content{

    white-space:pre-wrap;

    line-height:2;

    color:#e5e7eb;
}

/* COMMENTS */

.comments-box{

    background:#111827;

    padding:30px;

    border-radius:20px;

    margin-top:50px;
}

.comments-box h2{
    margin-bottom:25px;
}

textarea{

    width:100%;

    height:120px;

    padding:15px;

    background:#1f2937;

    border:none;

    border-radius:10px;

    color:white;

    margin-bottom:15px;

    resize:none;
}

button{

    padding:12px 20px;

    background:#ff7b29;

    border:none;

    border-radius:10px;

    color:white;

    cursor:pointer;
}

.comment{

    margin-top:25px;

    padding-bottom:20px;

    border-bottom:1px solid #1f2937;
}

.comment-user{

    color:#ffb37a;

    margin-bottom:10px;
}

.comment-time{

    margin-top:10px;

    color:#6b7280;

    font-size:13px;
}

</style>

</head>

<body>

<!-- NAVBAR -->

<div class="navbar">

<div class="logo">
INK<span>REALM</span>
</div>

<div class="nav-links">

<a href="stories.php">Stories</a>

<a href="upload.php">Write</a>

<a href="chapter_upload.php">Chapters</a>

</div>

</div>

<!-- CONTAINER -->

<div class="container">

<?php if(!empty($story_data['cover'])){ ?>

<img
class="cover"
src="uploads/<?php echo $story_data['cover']; ?>">

<?php } ?>

<h1>

<?php echo $story_data['title']; ?>

</h1>

<div class="author">

By

<a href="author.php?id=<?php echo $story_data['user_id']; ?>">

<?php echo $story_data['username']; ?>

</a>

</div>

<p class="description">

<?php echo $story_data['description']; ?>

</p>

<div class="stats">

👁️ Views:
<?php echo $story_data['views']; ?>

&nbsp;&nbsp;&nbsp;

❤️ Likes:
<?php echo $story_data['likes']; ?>

</div>

<a

class="like-btn"

href="read_story.php?id=<?php echo $story_id; ?>&like=<?php echo $story_id; ?>">

❤️ Like Story
<br><br>

<a

class="like-btn"

style="background:#2563eb;"

href="read_story.php?id=<?php echo $story_id; ?>&save=<?php echo $story_id; ?>">

📚 Save To Library

</a>
</a>

<!-- CHAPTERS -->

<?php while($chapter = mysqli_fetch_assoc($chapters)){ ?>

<div class="chapter">

<h2>

<?php echo $chapter['chapter_title']; ?>

</h2>

<div class="chapter-content">

<?php echo nl2br($chapter['chapter_content']); ?>

</div>

</div>

<?php } ?>

<!-- COMMENTS -->

<div class="comments-box">

<h2>
Comments
</h2>

<form method="POST">

<textarea

name="comment"

placeholder="Write a comment..."

required></textarea>

<button
type="submit"
name="submit_comment">

Post Comment

</button>

</form>

<?php while($comment = mysqli_fetch_assoc($comments)){ ?>

<div class="comment">

<h3 class="comment-user">

<?php echo htmlspecialchars($comment['username']); ?>

</h3>

<p>

<?php echo htmlspecialchars($comment['comment']); ?>

</p>

<p class="comment-time">

<?php echo $comment['created_at']; ?>

</p>

</div>

<?php } ?>

</div>

</div>

</body>

</html>